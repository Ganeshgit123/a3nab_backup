export const environment = {
  production: true,
  // baseUrl: 'http://15.185.182.194:3000/',
  // baseUrl: 'http://15.185.182.194/dev/'
  // baseUrl: 'http://65.1.122.8/dev/'
  baseUrl: 'http://65.1.122.8/api/'
  //  baseUrl: 'http://127.0.0.1:3002/'
};
